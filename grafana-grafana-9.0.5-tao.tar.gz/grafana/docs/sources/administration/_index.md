---
aliases:
  - /docs/grafana/latest/administration/
description: Administration
title: Administration
weight: 40
---

# Administration

This section includes information for Grafana administrators, team administrators, and users performing administrative tasks:

{{< section >}}

# Hall of fame

List of previous team members that have had a big impact on the company or the product and contributed during a long period of time.

- Hugo Häggmark ([School of applied technology](https://salt.study))
